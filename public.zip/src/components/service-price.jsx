import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import Suv from '../assets/images/suv.png'
import Tracktor from '../assets/images/tracktor.png'
import Sedan from '../assets/images/sedan2.png'
import Bus from '../assets/images/bus.png'
import { useTranslation } from 'react-i18next';

function ServicesAndPricing() {
  const { t, i18n } = useTranslation();
  const services = [
    { 
      description:t('servicePrice.sedan.description'), 
      price: t('servicePrice.sedan.price'), 
      image: Sedan
    },
    { 
      description: t('servicePrice.suv.description'), 
      price: t('servicePrice.suv.price'), 
      image: Suv 
    },
    { 
      description: t('servicePrice.tracktor.description'), 
      price:t('servicePrice.tracktor.price'), 
      image: Tracktor
    },
   
    { 
      description: t('servicePrice.minibus.description'), 
      price: t('servicePrice.minibus.price'), 
      image: Bus
    },
  ];

  const numCols = 2; // Количество столбцов
  // const colStyle = { maxWidth: '300px' }; // Стиль для столбцов
  const imgStyle = { maxWidth: '500px', height: 'auto', width:"100%", minWidth:"200px" }; // Стиль для изображений

  const numRows = Math.ceil(services.length / numCols); // Количество строк

  // Функция для рендеринга одной строки
  const renderRow = (startIndex) => {
    return (
      <Row key={startIndex} className="justify-content-center">
        {services.slice(startIndex, startIndex + numCols).map((service, index) => (
          <Col key={index} >
            <div className="text-center">
            <p >{service.description}</p>
            <p style={{fontWeight:"bold"}}><b>{service.price}</b></p>
              <img src={service.image} alt="Service" style={imgStyle} />
            </div>
          </Col>
        ))}
      </Row>
    );
  };

  // Рендеринг всех строк
  const renderRows = () => {
    const rows = [];
    for (let i = 0; i < numRows; i++) {
      rows.push(renderRow(i * numCols));
    }
    return rows;
  };

  return (
    <Container className="mt-5" id="tariff">
      <h2 className="text-center mb-4">{t('servicePrice.title')}</h2>
      <p className="text-center" style={{marginBottom:"100px"}}>{t('servicePrice.subtitle')}</p>
      {renderRows()}
    </Container>
  );
}

export default ServicesAndPricing;
